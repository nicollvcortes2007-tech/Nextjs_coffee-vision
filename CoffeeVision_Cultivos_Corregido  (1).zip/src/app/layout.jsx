import "../estilos/index.css";

export const metadata = {
  title: "Coffee+Vision",
  description: "Plataforma de apoyo para caficultores",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
