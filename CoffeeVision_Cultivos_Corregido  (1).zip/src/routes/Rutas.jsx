"use client";

import { Routes, Route, Navigate } from "react-router-dom";

import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import DashboardCaficultor from "@/pages/DashboardCaficultor";
import Cultivos from "@/pages/cultivos";
import EstadisticasCultivo from "@/pages/estadisticascultivo";

function Rutas() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/registro" element={<Signup />} />

      <Route
        path="/dashboard/caficultor"
        element={<DashboardCaficultor />}
      />

      {/* Se admiten las dos direcciones para evitar enlaces rotos. */}
      <Route path="/cultivos" element={<Cultivos />} />
      <Route path="/caficultor/cultivos" element={<Cultivos />} />

      <Route path="/estadisticas" element={<EstadisticasCultivo />} />
      <Route
        path="/caficultor/estadisticas"
        element={<EstadisticasCultivo />}
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default Rutas;
