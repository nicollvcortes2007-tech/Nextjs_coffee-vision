import { Notificaciones } from "@/features/notificaciones";

export default function Page() {
  return <Notificaciones />;
}
