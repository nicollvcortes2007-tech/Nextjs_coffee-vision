"use client";

import { usePerfilAdmin } from "../hooks/usePerfilAdmin";

function Campo({ id, label, error, children }) {
  return (
    <div className="min-w-0 space-y-1.5">
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      {children}
      {error && <p className="text-xs text-danger">Este campo es obligatorio.</p>}
    </div>
  );
}

function Dato({ etiqueta, valor, clase = "text-ink" }) {
  return (
    <div>
      <p className="text-[11px] text-muted">{etiqueta}</p>
      <p className={`break-all text-xs font-semibold ${clase}`}>{valor}</p>
    </div>
  );
}

export default function PerfilAdministrador() {
  const {
    pestanas,
    fotoPerfil,
    formulario,
    pestanaActiva,
    setPestanaActiva,
    errores,
    nombreCompleto,
    nombreDepartamento,
    handleChange,
    guardarCambios,
    cancelarCambios,
    seleccionarImagen,
    eliminarFoto,
  } = usePerfilAdmin();

  const campoClase = (campo) =>
    `w-full min-w-0 rounded-lg border ${
      errores[campo] ? "border-red-500" : "border-line"
    } bg-white px-3 py-2.5 text-sm text-ink outline-none focus:border-green focus:ring-2 focus:ring-green/20`;

  const entrada = (id, label, type = "text") => (
    <Campo id={id} label={label} error={errores[id]}>
      <input
        className={campoClase(id)}
        id={id}
        name={id}
        type={type}
        value={formulario[id]}
        onChange={handleChange}
        aria-invalid={Boolean(errores[id])}
      />
    </Campo>
  );

  return (
    <section className="box-border w-full min-w-0 bg-page">
      <div className="mx-auto w-full max-w-[1600px] space-y-4">
        {/* TÍTULO */}
        <header>
          <h2 className="text-xl font-bold text-ink">Mi perfil</h2>
          <p className="mt-1 text-sm text-muted">
            Gestiona tu información personal y configuración de la cuenta.
          </p>
        </header>

        <div className="grid min-w-0 grid-cols-1 items-stretch gap-5 xl:grid-cols-[280px_minmax(0,1fr)_300px]">
          {/* COLUMNA IZQUIERDA: PERFIL Y FOTO */}
          <article className="flex h-full min-w-0 flex-col justify-between overflow-hidden rounded-xl border border-line bg-surface shadow-panel">
            <div>
              <div className="flex flex-col items-center border-b border-line p-4">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={fotoPerfil}
                  alt="Foto del administrador"
                  className="h-16 w-16 rounded-full border-2 border-white object-cover shadow-sm"
                />
                <h3 className="mt-2 text-center text-sm font-bold text-coffee">{nombreCompleto}</h3>
                <p className="mt-2 rounded-full bg-green-soft px-3 py-1 text-center text-xs font-semibold text-green-deep">
                  Administrador del Sistema
                </p>
                <p className="mt-2 break-all text-center text-xs text-muted">{formulario.correo}</p>
              </div>

              <div className="space-y-2 border-b border-line p-4">
                <h3 className="text-sm font-bold text-ink">Foto del administrador</h3>
                <p className="text-xs leading-relaxed text-muted">
                  Formatos JPG, PNG y WEBP. Máximo 5 MB.
                </p>

                <label className="inline-flex w-full cursor-pointer items-center justify-center rounded-lg bg-green px-2 py-2 text-center text-xs font-semibold text-white transition hover:bg-green-deep">
                  ↑ Seleccionar imagen
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="sr-only"
                    onChange={seleccionarImagen}
                  />
                </label>

                <button
                  type="button"
                  className="w-full rounded-lg border border-line px-2 py-2 text-xs font-semibold text-danger transition hover:bg-red-50"
                  onClick={eliminarFoto}
                >
                  Eliminar foto
                </button>
              </div>
            </div>

            <div className="space-y-2.5 bg-page/30 p-4">
              <div className="flex items-start gap-2 text-xs text-muted">
                <span>📞</span>
                <span className="break-words">{formulario.telefono}</span>
              </div>
              <div className="flex items-start gap-2 text-xs text-muted">
                <span>📍</span>
                <span>
                  {formulario.municipio}, {nombreDepartamento}, Colombia
                </span>
              </div>
              <div className="border-t border-line pt-2.5 text-xs text-muted">
                📅 Miembro desde: 15/01/2024
              </div>
            </div>
          </article>

          {/* COLUMNA CENTRAL: FORMULARIO */}
          <div className="flex h-full min-w-0 flex-col overflow-hidden rounded-xl border border-line bg-surface shadow-panel">
            <form onSubmit={guardarCambios} noValidate className="flex h-full flex-col justify-between">
              <div>
                <nav className="border-b border-line bg-white px-3 sm:px-4">
                  <ul className="flex flex-wrap gap-x-1">
                    {pestanas.map((p) => (
                      <li key={p}>
                        <button
                          type="button"
                          className={`border-b-2 px-3 py-3 text-xs font-medium transition-colors sm:text-sm ${
                            pestanaActiva === p
                              ? "border-green font-semibold text-green-deep"
                              : "border-transparent text-muted hover:text-ink"
                          }`}
                          onClick={() => setPestanaActiva(p)}
                        >
                          {p}
                        </button>
                      </li>
                    ))}
                  </ul>
                </nav>

                {pestanaActiva === "Información personal" && (
                  <fieldset className="grid min-w-0 grid-cols-1 gap-x-4 gap-y-4 p-4 sm:grid-cols-2 sm:p-5">
                    <legend className="sr-only">Datos personales</legend>

                    {entrada("nombres", "Nombres")}
                    {entrada("apellidos", "Apellidos")}
                    {entrada("correo", "Correo electrónico", "email")}

                    <Campo id="rol" label="Rol">
                      <select className={campoClase("rol")} id="rol" name="rol" value={formulario.rol} onChange={handleChange}>
                        <option value="admin">Administrador</option>
                        <option value="editor">Editor</option>
                      </select>
                    </Campo>

                    {entrada("telefono", "Teléfono", "tel")}
                    {entrada("direccion", "Dirección")}
                    {entrada("municipio", "Municipio")}

                    <Campo id="departamento" label="Departamento">
                      <select
                        className={campoClase("departamento")}
                        id="departamento"
                        name="departamento"
                        value={formulario.departamento}
                        onChange={handleChange}
                      >
                        <option value="cauca">Cauca</option>
                        <option value="valle">Valle del Cauca</option>
                      </select>
                    </Campo>
                  </fieldset>
                )}

                {pestanaActiva === "Seguridad" && (
                  <section className="p-5">
                    <h3 className="font-semibold text-ink">Seguridad de la cuenta</h3>
                    <p className="mt-2 text-sm text-muted">
                      Administra la seguridad y protección de tu cuenta.
                    </p>
                    <div className="mt-4 rounded-lg border border-line p-4">
                      <p className="text-sm font-semibold text-ink">Protección de la cuenta</p>
                      <p className="mt-1 text-sm text-muted">
                        Mantén tus datos de acceso seguros y actualizados.
                      </p>
                    </div>
                  </section>
                )}

                {pestanaActiva === "Notificaciones" && (
                  <section className="p-5">
                    <h3 className="font-semibold text-ink">Notificaciones</h3>
                    <p className="mt-2 text-sm text-muted">
                      Configuración de las notificaciones de la cuenta.
                    </p>
                    <div className="mt-4 rounded-lg border border-line p-4">
                      <p className="text-sm font-semibold text-ink">Alertas del sistema</p>
                      <p className="mt-1 text-sm text-muted">
                        Consulta las novedades y mantente al tanto de la actividad de la plataforma.
                      </p>
                    </div>
                  </section>
                )}

                {pestanaActiva === "Actividad reciente" && (
                  <section className="p-5">
                    <h3 className="font-semibold text-ink">Actividad reciente</h3>
                    <p className="mt-2 text-sm text-muted">
                      Consulta la información general de la actividad de tu cuenta.
                    </p>
                    <div className="mt-4 space-y-3">
                      <div className="rounded-lg border border-line p-3">
                        <p className="text-sm font-semibold text-ink">Perfil consultado</p>
                        <p className="mt-1 text-xs text-muted">Información del administrador.</p>
                      </div>
                      <div className="rounded-lg border border-line p-3">
                        <p className="text-sm font-semibold text-ink">Cuenta activa</p>
                        <p className="mt-1 text-xs text-muted">
                          El perfil está disponible para su administración.
                        </p>
                      </div>
                    </div>
                  </section>
                )}
              </div>

              <footer className="flex flex-wrap justify-end gap-3 border-t border-line bg-page/60 p-4">
                <button
                  type="button"
                  className="rounded-lg border border-line bg-white px-4 py-2.5 text-sm font-semibold text-ink transition hover:bg-page"
                  onClick={cancelarCambios}
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-green px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-green-deep"
                >
                  ✓ Guardar cambios
                </button>
              </footer>
            </form>
          </div>

          {/* COLUMNA DERECHA: RESUMEN */}
          <aside className="flex h-full min-w-0 flex-col">
            <article className="flex h-full flex-col justify-between rounded-xl border border-line bg-surface p-4 shadow-panel">
              <div>
                <div className="flex items-center gap-3 border-b border-line pb-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={fotoPerfil} alt="Foto del administrador" className="h-11 w-11 rounded-full object-cover" />
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-ink">Administrador</h3>
                    <p className="text-xs text-green-deep">Administrador del Sistema</p>
                  </div>
                </div>

                <h3 className="mt-3 text-sm font-bold text-ink">Resumen de la cuenta</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted">
                  Información general del perfil administrador de Coffee + Visión.
                </p>

                <div className="mt-3 space-y-2.5">
                  <Dato etiqueta="Nombre completo" valor={nombreCompleto} />
                  <Dato etiqueta="Correo electrónico" valor={formulario.correo} />
                  <Dato
                    etiqueta="Rol asignado"
                    valor={formulario.rol === "admin" ? "Administrador" : "Editor"}
                    clase="text-green-deep"
                  />
                  <Dato etiqueta="Teléfono de contacto" valor={formulario.telefono} />
                  <Dato etiqueta="Dirección" valor={formulario.direccion} />
                  <Dato
                    etiqueta="Ubicación"
                    valor={`${formulario.municipio}, ${nombreDepartamento}, Colombia`}
                  />
                </div>
              </div>

              <div className="mt-3 space-y-3 border-t border-line pt-3">
                <div>
                  <h4 className="text-sm font-bold text-ink">Estado de la cuenta</h4>
                  <p className="mt-1 flex items-center gap-2 text-xs text-muted">
                    <span className="h-2 w-2 rounded-full bg-green" />
                    Cuenta activa
                  </p>
                  <p className="text-xs text-muted">Miembro desde: 15/01/2024</p>
                </div>

                <div className="border-t border-line pt-2">
                  <h4 className="text-sm font-bold text-ink">Recomendaciones</h4>
                  <ul className="mt-1.5 space-y-1 text-xs leading-relaxed text-muted">
                    <li>✓ Mantén actualizados tus datos.</li>
                    <li>✓ Utiliza un correo válido.</li>
                  </ul>
                </div>
              </div>
            </article>
          </aside>
        </div>
      </div>
    </section>
  );
}
