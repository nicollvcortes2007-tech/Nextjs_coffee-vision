"use client";

import { useState } from "react";
import {
  FOTO_POR_DEFECTO,
  PERFIL_ADMIN_INICIAL,
  PESTANAS_PERFIL,
} from "../services/perfilService";

const TIPOS_IMAGEN = ["image/jpeg", "image/png", "image/webp"];
const MAX_BYTES = 5 * 1024 * 1024;

export function usePerfilAdmin() {
  const [fotoPerfil, setFotoPerfil] = useState(FOTO_POR_DEFECTO);
  const [formulario, setFormulario] = useState(PERFIL_ADMIN_INICIAL);
  const [pestanaActiva, setPestanaActiva] = useState(PESTANAS_PERFIL[0]);
  const [errores, setErrores] = useState({});

  const nombreCompleto = `${formulario.nombres} ${formulario.apellidos}`.trim();
  const nombreDepartamento =
    formulario.departamento === "cauca" ? "Cauca" : "Valle del Cauca";

  const handleChange = (e) => {
    const { name, value } = e.target;
    const nuevoValor = name === "telefono" ? value.replace(/[^0-9+ ]/g, "") : value;

    setFormulario((prev) => ({ ...prev, [name]: nuevoValor }));

    if (nuevoValor.trim() !== "") {
      setErrores((prev) => ({ ...prev, [name]: false }));
    }
  };

  const guardarCambios = (e) => {
    e.preventDefault();

    const nuevosErrores = {};
    Object.entries(formulario).forEach(([campo, valor]) => {
      if (typeof valor === "string" && valor.trim() === "") nuevosErrores[campo] = true;
    });
    setErrores(nuevosErrores);

    if (Object.keys(nuevosErrores).length > 0) {
      alert("¡Todos los campos son obligatorios!");
      return;
    }
    alert("¡Información actualizada con éxito!");
  };

  const cancelarCambios = () => {
    setFormulario({ ...PERFIL_ADMIN_INICIAL });
    setErrores({});
  };

  const seleccionarImagen = (e) => {
    const archivo = e.target.files?.[0];
    if (!archivo) return;

    if (!TIPOS_IMAGEN.includes(archivo.type)) {
      alert("Selecciona una imagen JPG, PNG o WEBP.");
      e.target.value = "";
      return;
    }
    if (archivo.size > MAX_BYTES) {
      alert("La imagen no puede superar los 5 MB.");
      e.target.value = "";
      return;
    }

    const lector = new FileReader();
    lector.onload = (evento) => setFotoPerfil(evento.target.result);
    lector.readAsDataURL(archivo);
    e.target.value = "";
  };

  const eliminarFoto = () => setFotoPerfil(FOTO_POR_DEFECTO);

  return {
    pestanas: PESTANAS_PERFIL,
    fotoPerfil,
    formulario,
    pestanaActiva,
    setPestanaActiva,
    errores,
    nombreCompleto,
    nombreDepartamento,
    handleChange,
    guardarCambios,
    cancelarCambios,
    seleccionarImagen,
    eliminarFoto,
  };
}
