// barrel export de auth
export { default as PerfilAdministrador } from "./components/PerfilAdministrador";
export { usePerfilAdmin } from "./hooks/usePerfilAdmin";
