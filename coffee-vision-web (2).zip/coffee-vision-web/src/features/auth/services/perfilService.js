// Datos de ejemplo del administrador. Cuando el backend esté listo se
// reemplazan por llamadas con "@/lib/api" (GET/PUT /perfil).

export const FOTO_POR_DEFECTO = "/avatar-default.svg";

export const PESTANAS_PERFIL = [
  "Información personal",
  "Seguridad",
  "Notificaciones",
  "Actividad reciente",
];

export const PERFIL_ADMIN_INICIAL = {
  nombres: "Administrador",
  apellidos: "Sistema",
  correo: "admin@coffeetech.com",
  rol: "admin",
  telefono: "+57 300 123 4567",
  direccion: "Calle 5 #12-45, Centro",
  municipio: "Popayán",
  departamento: "cauca",
};
