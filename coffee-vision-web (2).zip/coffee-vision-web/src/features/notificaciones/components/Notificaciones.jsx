"use client";

import { useNotificaciones } from "../hooks/useNotificaciones";

export default function Notificaciones() {
  const {
    filtros,
    filtroActivo,
    setFiltroActivo,
    totalTodas,
    totalNoLeidas,
    registrosFiltrados,
    marcarComoLeida,
  } = useNotificaciones();

  const etiqueta = (filtro) =>
    filtro === "Todas"
      ? `Todas (${totalTodas})`
      : filtro === "No leídas"
      ? `No leídas (${totalNoLeidas})`
      : filtro;

  return (
    <section className="mx-auto box-border w-full max-w-6xl space-y-6 bg-page">
      {/* TÍTULO */}
      <header className="space-y-1">
        <h2 className="text-xl font-bold text-ink">Notificaciones</h2>
        <p className="text-sm text-muted">
          Revisa las alertas de tus cultivos, reportes del clima y estados del sistema.
        </p>
      </header>

      <div className="w-full min-w-0 space-y-6">
        {/* PESTAÑAS */}
        <nav className="w-full border-b border-line">
          <ul className="m-0 flex list-none flex-wrap gap-2 p-0">
            {filtros.map((filtro) => {
              const activo = filtroActivo === filtro;
              return (
                <li key={filtro}>
                  <button
                    type="button"
                    onClick={() => setFiltroActivo(filtro)}
                    className={`rounded-t border-b-2 px-4 py-2.5 text-sm font-medium transition-colors duration-150 ${
                      activo
                        ? "border-green font-semibold text-green"
                        : "border-transparent text-muted hover:text-ink"
                    }`}
                  >
                    {etiqueta(filtro)}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* CONTENEDOR DE ALTURA FIJA */}
        <div className="box-border h-[600px] max-h-[600px] min-h-[600px] w-full overflow-x-hidden overflow-y-auto">
          {registrosFiltrados.length === 0 ? (
            <div className="box-border flex h-full w-full items-center justify-center rounded border border-dashed border-line bg-surface p-6 text-center italic text-muted">
              No hay notificaciones disponibles en esta categoría.
            </div>
          ) : (
            <ul className="m-0 box-border flex min-h-full w-full list-none flex-col gap-3 p-0">
              {registrosFiltrados.map((registro) => (
                <li
                  key={registro.id}
                  className={`box-border flex h-[120px] max-h-[120px] min-h-[120px] w-full shrink-0 items-center justify-between gap-4 overflow-hidden rounded border bg-surface p-4 shadow-panel ${
                    registro.noLeida ? "border-l-4 border-l-green" : "border-line"
                  }`}
                >
                  {/* ICONO Y DESCRIPCIÓN */}
                  <div className="flex min-w-0 flex-1 items-start gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-line bg-page text-lg">
                      {registro.emoji}
                    </span>

                    <article className="min-w-0 flex-1 overflow-hidden">
                      <h3 className="truncate text-sm font-bold text-ink">{registro.titulo}</h3>
                      <p className="text-xs leading-relaxed text-muted overflow-hidden [display:-webkit-box] [-webkit-box-orient:vertical] [-webkit-line-clamp:2]">
                        {registro.descripcion}
                      </p>
                      <time className="block pt-1 text-[11px] text-muted/80">{registro.tiempo}</time>
                    </article>
                  </div>

                  {/* ESPACIO CONSTANTE PARA EL BOTÓN */}
                  <div className="w-[125px] shrink-0">
                    {registro.boton && registro.noLeida && (
                      <button
                        type="button"
                        className="flex w-full items-center justify-center gap-1 rounded border border-line bg-page p-2 text-xs font-semibold text-ink transition-colors hover:bg-green hover:text-surface"
                        onClick={() => marcarComoLeida(registro.id)}
                        title="Marcar como leída"
                      >
                        ✓ Marcar leída
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}
