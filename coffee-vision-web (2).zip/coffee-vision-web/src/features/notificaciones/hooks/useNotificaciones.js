"use client";

import { useMemo, useState } from "react";
import { FILTROS, obtenerNotificaciones } from "../services/notificacionesService";

export function useNotificaciones() {
  const [registros, setRegistros] = useState(obtenerNotificaciones);
  const [filtroActivo, setFiltroActivo] = useState(FILTROS[0]);

  const totalTodas = registros.length;
  const totalNoLeidas = registros.filter((r) => r.noLeida).length;

  const registrosFiltrados = useMemo(() => {
    switch (filtroActivo) {
      case "No leídas":
        return registros.filter((r) => r.noLeida);
      case "Críticas":
        return registros.filter((r) => r.tipo === "critica");
      case "Alertas de Cultivo":
        return registros.filter((r) => r.esAlertaCultivo);
      default:
        return registros;
    }
  }, [registros, filtroActivo]);

  const marcarComoLeida = (id) => {
    setRegistros((actuales) =>
      actuales.map((r) => (r.id === id ? { ...r, noLeida: false, boton: false } : r))
    );
  };

  return {
    filtros: FILTROS,
    filtroActivo,
    setFiltroActivo,
    totalTodas,
    totalNoLeidas,
    registrosFiltrados,
    marcarComoLeida,
  };
}
