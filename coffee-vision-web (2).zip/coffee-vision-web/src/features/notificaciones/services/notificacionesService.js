// Datos de ejemplo. Cuando el backend esté listo, se reemplazan por llamadas
// con "@/lib/api" (por ejemplo: api.get("/notificaciones")).

export const FILTROS = ["Todas", "No leídas", "Críticas", "Alertas de Cultivo"];

const registrosIniciales = [
  { id: 1, emoji: "🐛", titulo: "Alerta de Plaga Detectada", descripcion: "El sistema de IA ha detectado un posible brote de Roya del café en el Lote 3 (Variedad Castillo). Se recomienda inspección inmediata.", tiempo: "Hace 15 minutos", tipo: "critica", esAlertaCultivo: true, noLeida: true, boton: true },
  { id: 2, emoji: "🐞", titulo: "Ataque Severo de Broca", descripcion: "Se ha identificado un nivel de infestación de broca superior al 5% en el Lote 2. Requiere muestreo y control biológico urgente.", tiempo: "Hace 30 minutos", tipo: "critica", esAlertaCultivo: true, noLeida: true, boton: true },
  { id: 3, emoji: "🍂", titulo: "Foco de Mancha de Hierro", descripcion: "Aparición de manchas foliares en el almácigo del Lote 4 debido a alta humedad y deficiencia nutricional.", tiempo: "Hace 1 hora", tipo: "critica", esAlertaCultivo: true, noLeida: true, boton: true },
  { id: 4, emoji: "⚠️", titulo: "Deficiencia Crítica de Nitrógeno", descripcion: "Análisis foliar muestra clorosis severa en hojas viejas del Lote 1. Aplicar fertilización foliar de rescate.", tiempo: "Hace 2 horas", tipo: "critica", esAlertaCultivo: true, noLeida: false, boton: false },
  { id: 5, emoji: "🌱", titulo: "Sugerencia de Fertilización de Cultivo", descripcion: "Momento óptimo para la aplicación del fertilizante NPK en el Lote 1 tras inicio de lluvias.", tiempo: "Hace 3 horas", tipo: "fertilizacion", esAlertaCultivo: true, noLeida: true, boton: true },
  { id: 6, emoji: "🌾", titulo: "Control de Malezas Pendiente", descripcion: "Crecimiento excesivo de arvenses competidoras en las calles del Lote 3. Programar desyerbe manual.", tiempo: "Hace 4 horas", tipo: "manejo", esAlertaCultivo: true, noLeida: true, boton: true },
  { id: 7, emoji: "✂️", titulo: "Alerta de Poda y Zoqueo", descripcion: "Cafetos del Lote 5 han alcanzado la fase de agotamiento productivo. Se sugiere programación de poda zoca.", tiempo: "Hace 5 horas", tipo: "manejo", esAlertaCultivo: true, noLeida: false, boton: false },
  { id: 8, emoji: "🌸", titulo: "Monitoreo de Floración del Café", descripcion: "Se registra el pico principal de floración en la Parcela Central. Evitar aplicación de agroquímicos durante esta semana.", tiempo: "Ayer", tipo: "manejo", esAlertaCultivo: true, noLeida: false, boton: false },
  { id: 9, emoji: "☕", titulo: "Aviso de Recolección de Grano Maduro", descripcion: "Índice de maduración del fruto alcanzó el 80% en el Lote 2. Iniciar pase de cosecha para evitar grano sobremaduro.", tiempo: "Hace 2 días", tipo: "cosecha", esAlertaCultivo: true, noLeida: false, boton: false },
  { id: 10, emoji: "📊", titulo: "Reporte Mensual Generado", descripcion: "El informe detallado de rendimiento y estadísticas de cosecha correspondiente al mes pasado ya está disponible para su descarga.", tiempo: "Hace 3 días", tipo: "reporte", esAlertaCultivo: false, noLeida: false, boton: false },
];

export function obtenerNotificaciones() {
  return registrosIniciales.map((r) => ({ ...r }));
}
