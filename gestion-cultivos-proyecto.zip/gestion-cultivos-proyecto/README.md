# Gestión de Cultivos

Este repositorio contiene la vista de **Gestión de Cultivos** para el proyecto agrícola/cafetero.

## Estructura
- `src/pages/GestionDeCultivos.jsx`: Componente React principal.

## Instrucciones para subir a GitHub
1. Descomprime esta carpeta.
2. Abre la terminal en esta carpeta.
3. Ejecuta:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Vista Gestión de Cultivos"
   git branch -M main
   git remote add origin https://github.com/tu-usuario/tu-repositorio.git
   git push -u origin main
   ```
